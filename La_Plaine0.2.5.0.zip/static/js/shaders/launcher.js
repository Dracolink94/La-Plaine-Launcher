/* Gestionnaire de shaders plein écran au format ZIP de La Plaine. */
(function () {
    class ShaderPackRenderer {
        constructor(renderer) {
            this.renderer = renderer;
            this.target = null;
            this.scene = new THREE.Scene();
            this.camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
            this.material = null;
            this.mesh = null;
            this.startedAt = performance.now();
            this.resize();
        }
        resize() {
            const canvas = this.renderer.domElement;
            const width = Math.max(2, canvas.width || 2);
            const height = Math.max(2, canvas.height || 2);
            if (this.target) this.target.dispose();
            this.target = new THREE.WebGLRenderTarget(width, height, {
                minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
                format: THREE.RGBAFormat, depthBuffer: true, stencilBuffer: false
            });
            if (this.material) {
                this.material.uniforms.uResolution.value.set(width, height);
            }
        }
        async setActive(id) {
            if (!id || id === 'off') { this.clear(); return; }
            const response = await fetch('/api/shaders/' + encodeURIComponent(id), { cache: 'no-store' });
            if (!response.ok) throw new Error('Shader introuvable : ' + id);
            const pack = await response.json();
            const vertexShader = pack.vertex_shader || `
                varying vec2 vUv;
                void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
            `;
            const fragmentShader = pack.fragment_shader;
            if (typeof fragmentShader !== 'string' || !fragmentShader.trim()) throw new Error('Le pack ne contient pas de fragment shader.');
            const next = new THREE.ShaderMaterial({
                uniforms: {
                    tDiffuse: { value: null },
                    uTime: { value: 0 },
                    uResolution: { value: new THREE.Vector2(this.renderer.domElement.width, this.renderer.domElement.height) }
                },
                vertexShader, fragmentShader,
                depthTest: false, depthWrite: false
            });
            if (this.material) this.material.dispose();
            this.material = next;
            if (this.mesh) this.scene.remove(this.mesh);
            this.mesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.material);
            this.scene.add(this.mesh);
            this.resize();
        }
        clear() {
            if (this.material) this.material.dispose();
            if (this.mesh) { this.scene.remove(this.mesh); this.mesh.geometry.dispose(); }
            this.material = null; this.mesh = null;
        }
        render(scene, camera) {
            if (!this.material || !this.target) { this.renderer.render(scene, camera); return; }
            this.material.uniforms.uTime.value = (performance.now() - this.startedAt) / 1000;
            this.material.uniforms.tDiffuse.value = this.target.texture;
            this.renderer.setRenderTarget(this.target);
            this.renderer.render(scene, camera);
            this.renderer.setRenderTarget(null);
            this.renderer.render(this.scene, this.camera);
        }
        dispose() { this.clear(); if (this.target) this.target.dispose(); }
    }
    window.ShaderPackRenderer = ShaderPackRenderer;
})();
